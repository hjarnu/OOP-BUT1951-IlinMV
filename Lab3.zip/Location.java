/**
 Класс Location создает 2D карту
 **/
public class Location
{
    public int xCoord; // координата x

    public int yCoord; // координата y


    /**
     Создание новой ячейки с определенными ранее координатами
     **/
    public Location(int x, int y)
    {
        xCoord = x;
        yCoord = y;
    }

    /**
     Создание новой ячейки с координатами 0,0 по умолчанию
     **/
    public Location()
    {
        this(0, 0);
    }

    /**
     Метод equals предназначен для сравнения двух объектов
    **/
    public boolean equals(Object object)
    {
        if (object == null) {
            return false;
        }
        if (object instanceof Location)
        {
            Location other = (Location) object;

            if (xCoord == other.xCoord &&
                    yCoord == other.yCoord)
            {
                return true;
            }
        }

        return false;
    }

    /**
     Метод hashCode возвращает числовое значение фиксированной длины для любого объекта.
     **/
    public int hashCode()
    {
        int result = 83;
        result = 52 * result + (xCoord * 96);
        result = 11 * result + (yCoord * 49);

        return result;
    }
}
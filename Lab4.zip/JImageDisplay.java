import javax.swing.JComponent;
import java.awt.image.BufferedImage;
import java.awt.Dimension;
import java.awt.Graphics;

/**
 * Класс JImageDisplay представляет собой графический виджет, который будет отображать фракталы
 */
public class JImageDisplay extends JComponent {

    private BufferedImage image;

    /**
     Метод JImageDisplay принимает целочисленные значения ширины и высоты и инициализирует объект BufferedImage
     с этими значениями и типом изображения TYPE_INT_RGB
     */
    public JImageDisplay(int width, int height) {
	image = new BufferedImage(width,height, BufferedImage.TYPE_INT_RGB);
	//TYPE_INT_RGB обозначает, что красные, зеленые и синие компоненты имеют по 8 битов,
        // представленные в формате int в указанном порядке.

	Dimension size = new Dimension(width, height);
	//вызов метода setPreferredSize() родительского класса с указанной шириной и высотой.
	super.setPreferredSize(size);
    }

    /**
        Класс paintComponent рисует изображение
     */
    public void paintComponent(Graphics g) {
	super.paintComponent(g);
    //Здесь мы рисуем новое изображение
	g.drawImage(image, 0, 0, image.getWidth(), image.getHeight(), null);
    }

    /**
    Метод устанавливает пиксел в определенный цвет
     */
    public void drawPixel(int x, int y, int rgbColor) {
	image.setRGB(x, y, rgbColor);
    }
    /**
     Метод устанавливает все пиксели в черный цвет
     */
    public void clearImage() {
	for (int i = 0; i < image.getWidth(); i++) {
	    for (int j = 0; j < image.getHeight(); j++) {
		drawPixel(i, j, 0);
	    }
	}
    }

    public BufferedImage getImage() {
        return image;
    }

}
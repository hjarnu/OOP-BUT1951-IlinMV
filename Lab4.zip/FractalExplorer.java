import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.geom.Rectangle2D;
import javax.swing.*;

/**
 Коасс FractalExplorer позволяет исследовать различные области фрактала путем его создания и отображения через
 графический интерфейс.
 */
public class FractalExplorer {

    private int _displaySize; // Размер экрана

    private JImageDisplay _image; // Ссылка JImageDisplay, для обновления отображения в разных методах в процессе вычисления фрактала

    private JComboBox<String> _fractalChooser; // Display of multiple fractals

    private JButton _resetButton; // Сбрасывает изображение

    private FractalGenerator _gen;

    private Rectangle2D.Double _range; // Указывает диапазон комплексной плоскости, которая выводится на экран

    private int _rowsRemaining; // Use it to know when redraw is completed

    /**
     Скрывает кнопки во время отображения фрактала
     */
    private void enableUI(boolean val) {
        _fractalChooser.setEnabled(val);

        _resetButton.setEnabled(val);
    }

    private class FractalWorker extends SwingWorker<Object, Object> {

        private int _y;

        private int[] _RGBVals;

        public FractalWorker(int y) {
            _y = y;
        }

        public Object doInBackground() {
            _RGBVals = new int[_displaySize];

            double yCoord = FractalGenerator.getCoord(_range.y, _range.y + _range.height,
                    _displaySize, _y);

            for (int x = 0; x < _displaySize; x++) {

                double xCoord = FractalGenerator.getCoord(_range.x, _range.x + _range.width,
                        _displaySize, x);
                int numIters;
                int rgbColor = 0;
                float hue;

                numIters = _gen.numIterations(xCoord, yCoord);
                if (numIters >= 0) {
                    hue = 0.7f + numIters / 200f;
                    rgbColor = Color.HSBtoRGB(hue, 1f, 1f);
                }

                _RGBVals[x] = rgbColor;
            }

            return null;
        }

        public void done() {
            for (int x = 0; x < _displaySize; x++) {
                _image.drawPixel(x, _y, _RGBVals[x]);
            }

            _image.repaint(0, 0, _y, _displaySize, 1);

            if (_rowsRemaining-- < 1) {
                enableUI(true);
            }
        }
    }

    private class FractalHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();

            if (e.getSource() == _fractalChooser) {
                String selectedItem = _fractalChooser.getSelectedItem().toString();

                if (selectedItem.equals(Mandelbrot.getString()))  {
                    _gen = new Mandelbrot();
                }
                else {
                    JOptionPane.showMessageDialog(null, "Error: Couldn't recognize choice");
                    return;
                }

                _range = new Rectangle2D.Double();
                _gen.getInitialRange(_range);

                drawFractal();
            }
            else if (cmd.equals("reset")) {
                _range = new Rectangle2D.Double();
                _gen.getInitialRange(_range);

                drawFractal();
            }
            else {
                JOptionPane.showMessageDialog(null, "Error: Couldn't recognize action");
            }
        }
    }

    /**
     При получении события о щелчке мышью,
     класс должен отобразить пиксельные кооринаты щелчка в область фрактала,
     а затем вызвать метод генератора recenterAndZoomRange() c координатами, по которым щелкнули, и масштабом 0.5.
     */
    private class MouseHandler extends MouseAdapter {

        public void mouseClicked(MouseEvent e) {

            if (_rowsRemaining > 0) {
                return;
            }
            // Определение координат с плаваюзей точкой для определенного набора пикселей
            double xCoord = FractalGenerator.getCoord(_range.x, _range.x + _range.width,
                    _displaySize, e.getX());

            double yCoord = FractalGenerator.getCoord(_range.y, _range.y + _range.height,
                    _displaySize, e.getY());

            _gen.recenterAndZoomRange(_range, xCoord, yCoord, 0.5);

            drawFractal();
        }
    }

    public FractalExplorer(int size) {
        _displaySize = size;

        _gen = new Mandelbrot();

        _range = new Rectangle2D.Double();
        _gen.getInitialRange(_range);
    }

    /**
     Метод инициализирует графический интерфейс
     */
    public void createAndShowGUI() {
        JFrame frame  = new JFrame("Фракталы");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.getContentPane().setLayout( new BorderLayout());

        FractalHandler handler = new FractalHandler();

        // Choose fractal
        JPanel fractalPanel = new JPanel();

        JLabel label = new JLabel("Fractal: ");
        fractalPanel.add(label);

        _fractalChooser = new JComboBox<String>();
        _fractalChooser.addItem(Mandelbrot.getString());
        _fractalChooser.addActionListener(handler);

        fractalPanel.add(_fractalChooser);

        frame.getContentPane().add(fractalPanel, BorderLayout.NORTH);

        // Image
        _image = new JImageDisplay(_displaySize, _displaySize);
        frame.getContentPane().add(_image, BorderLayout.CENTER);

        //
        JPanel buttonsPanel = new JPanel();


        // Кнопка для сброса изображения
        _resetButton = new JButton("Сбросить изображение");
        _resetButton.setActionCommand("reset");
        _resetButton.addActionListener(handler);
        buttonsPanel.add(_resetButton);

        frame.getContentPane().add(buttonsPanel, BorderLayout.SOUTH);

        frame.getContentPane().addMouseListener(new MouseHandler());
        frame.pack();
        frame.setVisible(true);
        frame.setResizable(false);
    }

    /**
     Вывод на экран фрактала. Метод циклически проходит через каждый пиксель в изображении
     */
    public void drawFractal() {
        enableUI(false);

        for (int y = 0; y < _displaySize; y++) {
            FractalWorker worker = new FractalWorker(y);
            worker.execute();
        }

        _image.repaint();
    }

    /**
     Запуск программы в окне размером 800
     */

    public static void main(String[] args) {
        FractalExplorer explorer = new FractalExplorer(800);
        explorer.createAndShowGUI();
        explorer.drawFractal();
    }
}
import java.awt.geom.Rectangle2D;

/**
 Класс вычисляет фрактал Мандельброта
 */
public class Mandelbrot extends FractalGenerator {
	//Максимальное количество итераций
    public static final int MAX_ITERATIONS = 2000;
	/**
	 Метод getInitialRange устанавливает начальный диапазон (-2 - 1.5i) - (1 + 1.5i)
	 */
    public void getInitialRange(Rectangle2D.Double range) {
	range.x = -2;
	range.y = -1.5;

	range.width = 3;
	range.height = 3;
    }

    /**
	 Метод numIterations вычисляет фрактал, пока значение |z| > 2, либо пока алгоритм не достигнет максимального количества
	 итераций
     */

    public int numIterations(double x, double y) {
	int count = 0;
	
	double re = 0;
	double im = 0;
	double z_n2 = 0;
	
	while (count < MAX_ITERATIONS && z_n2 < 4) {
	    count++;
	    
	    double nextRe = Math.pow(re, 2) - Math.pow(im, 2) + x;
	    double nextIm = 2 * re * im + y;

	    z_n2 = Math.pow(nextRe, 2) + Math.pow(nextIm, 2);

	    re = nextRe;
	    im = nextIm;	   
	}
	//Когда алгоритм дойдет до значения MAX_ITERATIONS, возвращаем -1
	return count < MAX_ITERATIONS ? count : -1;
    }
    
    public static String getString() {
	return "Mandelbrot";
    }
}